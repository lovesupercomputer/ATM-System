-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2015 at 06:45 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `11112222`
--

CREATE TABLE IF NOT EXISTS `11112222` (
  `credit` int(11) NOT NULL,
  `debit` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `11112222`
--

INSERT INTO `11112222` (`credit`, `debit`, `date`) VALUES
(111, 0, '2015-06-04 23:39:43'),
(111, 0, '2015-06-04 23:39:43'),
(1000, 0, '2015-06-04 23:45:57'),
(222, 0, '2015-06-04 23:59:59'),
(0, 700, '2015-06-05 00:16:18'),
(0, 125, '2015-06-05 01:01:15'),
(0, 20, '2015-06-05 01:05:21'),
(0, 200, '2015-06-05 01:33:03'),
(5000, 0, '2015-06-05 10:13:42');

-- --------------------------------------------------------

--
-- Table structure for table `33334444`
--

CREATE TABLE IF NOT EXISTS `33334444` (
  `credit` int(11) NOT NULL,
  `debit` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `33334444`
--

INSERT INTO `33334444` (`credit`, `debit`, `date`) VALUES
(0, 200, '2015-06-05 00:03:58'),
(600, 0, '2015-06-05 00:28:04'),
(125, 0, '2015-06-05 01:01:15'),
(20, 0, '2015-06-05 01:05:21'),
(0, 5000, '2015-06-05 10:13:42');

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `atmnumber` int(16) NOT NULL,
  `current_balance` int(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`atmnumber`, `current_balance`) VALUES
(11112222, 5994),
(33334444, 7045);

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE IF NOT EXISTS `details` (
  `atmnumber` bigint(16) NOT NULL,
  `name` varchar(100) NOT NULL,
  `pin` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`atmnumber`, `name`, `pin`) VALUES
(00001111, 'Deepak', 0012),
(11112222, 'Rituraj', 1234),
(33334444, 'shashikant', 2345);
(44445555, 'Shadabul', 4325),

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
