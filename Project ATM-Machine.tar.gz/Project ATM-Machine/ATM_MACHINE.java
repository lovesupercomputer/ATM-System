//*************************************************ATM MACHINE PROJECT **********************************************
import java.sql.*; 
import java.util.Scanner; 


class atm{  


     public static void main(String args[])
	 {  
     
	 
	 
	 try{  
         Class.forName("com.mysql.jdbc.Driver");  
  

         Connection con=DriverManager.getConnection(  "jdbc:mysql://localhost:3306/customers","root","");  
  

  
         Statement stmt=con.createStatement();  
  

	  
	     int atm=0;
	      String name=new String("df");
	      int pin=0;
	      Scanner dss=new Scanner(System.in);
		  System.out.println("*******************WELCOME TO STATE BANK OF INDIA***************************");
	      System.out.print("Enter your ATM number:  ");
	      int useratm=dss.nextInt();
	  
	      ResultSet rs=stmt.executeQuery("SELECT * FROM `details` WHERE `atmnumber`="+useratm);  
  
          while(rs.next())   
		  {
 
             atm=rs.getInt(1);
	         name=rs.getString(2);
	         pin=rs.getInt(3);

           }
          if(name.equals("df"))
		  {
	       System.out.println("Card not found");
	       return;
          }
          else
          System.out.print("Welcome "+name+"!\n\n Please Enter your pin:   ");
          int userpin=dss.nextInt();
          if(userpin==pin)
          {
	      System.out.print("Hello "+name+"\n\n1 - Withdrawal\n2 - Deposit\n3 - BalanceEnquiry\n4 - Mini Statement\n5 - Transfer Money\n6 - Change PIN\n\nChoose your Option:  ");
	      int c=dss.nextInt();
	   
	   
	   switch(c)
	   {
		   
		   case 1:
		      withdrawal(atm);
		   break;
		   case 2:
		    deposit(atm);
		   
		   break;
		   case 3:
		      bal_enquiry(atm,1);
		   break;
		   case 4:
		      mini_statement(atm);
			  
		   break;
		   case 5:
		       transfer(atm);
		   break;
		   case 6:
		       changepin(atm);
		   break;
		   default:
		   System.out.println("Invalid response:");
		   
		}
   }
 else
	 System.out.println("Incorrect Pin!");
     con.close();  
  
}catch(Exception e)
{
	System.out.println(e);
}  
  
}  



                /******FUNCTION FOR BALANCE ENQUIRY**********/

static int bal_enquiry(int atmnumber,int flg)
{
	int bal=0;
	int nm=0;
	
	try{

Connection con=DriverManager.getConnection(  "jdbc:mysql://localhost:3306/customers","root","");  
  

  
Statement stmt=con.createStatement();  
	
	ResultSet rs=stmt.executeQuery("SELECT * FROM `account` WHERE `atmnumber`="+atmnumber);  
	
	while(rs.next())   {
 
     nm=rs.getInt(1);
	
	 bal=rs.getInt(2);

}
	if(flg==1)
	System.out.println("Your Current balance is "+bal);
	
	

}catch(Exception e){ System.out.println(e);} 
return bal;
}  


                        /*********FUNCTION FOR DEPOSIT THE AMOUNT**********/


static void deposit(int atmnumber)
{
	try{

Connection con=DriverManager.getConnection(  "jdbc:mysql://localhost:3306/customers","root","");  
  
   Scanner dss=new Scanner(System.in);
  
Statement stmt=con.createStatement();  
	int bal=0;
	int wm=0;
	System.out.println("Enter the amount you want to Deposit:");
	wm=dss.nextInt();
	String sql = "UPDATE `account` SET `current_balance`=`current_balance`+"+wm+" WHERE `atmnumber`="+atmnumber;
      stmt.executeUpdate(sql);
	
	System.out.println("Your Account is successfully credited with Rs "+wm);
	bal_enquiry(atmnumber,1);
	update(atmnumber,1,wm);
	

}catch(Exception e){ System.out.println(e);} 

}


                              /*********FUNCTION FOR WITHDRAWAL THE AMOUNT **********/




static void withdrawal(int atmnumber)
{
	try{

Connection con=DriverManager.getConnection(  "jdbc:mysql://localhost:3306/customers","root","");  
  
   Scanner dss=new Scanner(System.in);
  
Statement stmt=con.createStatement();  
	int bal=0;
	int wm=0;
	System.out.println("Enter the amount you want to Withdraw :");
	
	wm=dss.nextInt();
	bal=bal_enquiry(atmnumber,0);
	if(bal>=wm){
	String sql = "UPDATE `account` SET `current_balance`=`current_balance`-"+wm+" WHERE `atmnumber`="+atmnumber;
      stmt.executeUpdate(sql);
	
	System.out.println("Your Account is successfully debited with Rs. "+wm);
	}
	else
		System.out.println("Transaction Failed\nInsufficient Amount ");
	bal_enquiry(atmnumber,1);
	update(atmnumber,2,wm);
	

}catch(Exception e){ System.out.println(e);} 
	
}


                                /*********FUNCTION FOR UPDATE**********/


static void update(int atmnumber,int cc,int amount)
{
	try{

Connection con=DriverManager.getConnection(  "jdbc:mysql://localhost:3306/customers","root","");  
  
   
  
Statement stmt=con.createStatement(); 
 
    
    if(cc==1){
   String sql = "INSERT INTO `"+atmnumber+"` VALUES ("+amount+",0,NOW())";
      stmt.executeUpdate(sql);
	}
	else
	{
		String sql = "INSERT INTO `"+atmnumber+"` VALUES (0,"+amount+",NOW())";
       stmt.executeUpdate(sql);
		
	}


	}catch(Exception e){ System.out.println(e);} 
	
	
}



                                 /*********FUNCTION FOR MINI STATEMENT**********/



 static void mini_statement(int atmnumber)
 {
	 
	 try{

Connection con=DriverManager.getConnection(  "jdbc:mysql://localhost:3306/customers","root","");  
  

  
Statement stmt=con.createStatement();  
	
	ResultSet rs=stmt.executeQuery("SELECT * FROM `"+atmnumber+"`");
	
	while(rs.next())  
System.out.println("Credited By rs: "+rs.getInt(1)+"   Debited By rs: "+rs.getInt(2)+"  On Date-Time:  "+rs.getString(3)+"\n\n"); 
	 
	 
	 
	 
	 }catch(Exception e){ System.out.println(e);} 
	 
 }
 
 
                  /*******************FUNCTION FOR MONEY TRANSFER********************/
 
 
 static void transfer(int atmnumber)
 {
	 
	 System.out.println("Enter the ATM Number in which you want to transfer money:");
	 Scanner dss=new Scanner(System.in);
	 int atmt=dss.nextInt();
	 try{
		 Connection con=DriverManager.getConnection(  "jdbc:mysql://localhost:3306/customers","root","");  
         Statement stmt=con.createStatement();
          
         
         
		  ResultSet rs=stmt.executeQuery("SELECT * FROM `details` WHERE `atmnumber`="+atmt);  
          String name=new String("df");
		  
          while(rs.next())   
		  {
 
             
	         name=rs.getString(2);

           } 
		   
		   System.out.println("Enter the amount you want to transfer:");
		   int amnt=dss.nextInt();
		   if(name.equals("df"))
		   {
			   System.out.println("No Account corresponds to this ATM- "+atmt);
			   return ;
		   }
		   else
		   {
			   System.out.println("Are you sure want to transfer Rs"+amnt+" to "+name+" having ATM number- "+atmt+"? (y/n)");
			   char cc=dss.next().charAt(0);
			   if(cc=='y'||cc=='Y')
			   {   
		           int bal=0;
				   bal=bal_enquiry(atmnumber,0);
				   if(bal>=amnt)
				   {
				   String sql = "UPDATE `account` SET `current_balance`=`current_balance`+"+amnt+" WHERE `atmnumber`="+atmt;
                   stmt.executeUpdate(sql);
				   update(atmt,1,amnt);
				    sql = "UPDATE `account` SET `current_balance`=`current_balance`-"+amnt+" WHERE `atmnumber`="+atmnumber;
                   stmt.executeUpdate(sql);
				   update(atmnumber,2,amnt);
				   System.out.println("Transaction Successful");
				   bal_enquiry(atmnumber,1);
				   }
				   else
				   {
					   System.out.println("Insufficient amount!");
					   return ;
				   }
				   
			   }
			   else
			   {
				   System.out.println("Transaction Aborted!");
				   return;
			   }
			   
			   
			   
		   }
		 
	     }
	 catch(Exception e){ System.out.println(e);} 
	 
	 
 }
 
 
                    /********************FUNCTION FOR PIN CHANGE********************/
 
 
 
 static void changepin(int atmnumber)
 {
	 
	  try{
		 Connection con=DriverManager.getConnection(  "jdbc:mysql://localhost:3306/customers","root","");  
         Statement stmt=con.createStatement();
		 
		  ResultSet rs=stmt.executeQuery("SELECT * FROM `details` WHERE `atmnumber`="+atmnumber);  
          int cpin=0;
		  
          while(rs.next())   
		  {
 
            
	         cpin=rs.getInt(3);

           } 
		   System.out.println("Please Enter your Current pin:");
		   Scanner dss=new Scanner(System.in);
		   int epin=dss.nextInt();
		   if(epin==cpin)
		   {
			   System.out.println("Enter your new PIN(4 digit):");
			   int npin=dss.nextInt();
			   System.out.println("Renter your new PIN(4 digit):");
			   int npin1=dss.nextInt();
			   if(npin==npin1)
			   {
				   String sql = "UPDATE `details` SET `pin`="+npin+" WHERE `atmnumber`="+atmnumber;
                   stmt.executeUpdate(sql);
				   System.out.println("PIN Changed Successfully!");
			   }
			   else
			   {
				   System.out.println("Didn't match!");
				   changepin(atmnumber);
			   }
			   
		   }
		   else
		   {
			   System.out.println("Incorrect pin!");
			   return ;
			   
		   }
		 
		 
		 
	  }
	 catch(Exception e){ System.out.println(e);} 
	 
 }
 
 
 

}